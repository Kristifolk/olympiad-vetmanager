<?php
require_once dirname(__DIR__, 1) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "config.php";

require_once dirname(__DIR__, 1) .  DIRECTORY_SEPARATOR . "App.php";

exit(0);