<?php

namespace App\Services\Task;

class AddressClinic
{
    public function getCurrentUrlAddressOfTheClinic() :string
    {
        return "31af0669fd1bcd6d145410795a6ef4f7";
    }
}