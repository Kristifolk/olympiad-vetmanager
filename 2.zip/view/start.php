<section class="container section-start">
    <h2>Олимпиада по работе с программным обеспечением VETMANAGER</h2>
    <h3>Выполните все задания и проверте свои навыки на практике</h3>
    <a class="btn btn-for-a btn-start" href="/authorization" type="button">Начать прохождение</a>
</section>