<div class="container-not-found">
    <h1 class="header-not-found">404</h1>
    <p>Страница не найдена</p>
</div>